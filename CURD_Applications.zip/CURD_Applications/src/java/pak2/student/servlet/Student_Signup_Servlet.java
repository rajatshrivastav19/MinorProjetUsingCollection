package pak2.student.servlet;
import pak1.student.database.StudnetDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
@WebServlet("/Student_Signup_Servlet")
public class Student_Signup_Servlet extends  HttpServlet
{
    String name,email,password,standerd;
    int sid;
    PrintWriter out;
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException , ServletException
    {
        try {
            this.name=req.getParameter("name");
            this.email=req.getParameter("email");
            this.password=req.getParameter("password");
            this.standerd=req.getParameter("standerd");
            this.sid=Integer.parseInt(req.getParameter("sid"));
            out=res.getWriter();
            out.print("<h1>"+this.name+"</h1>");
            StudnetDatabase s1=new StudnetDatabase(this.name, this.email, this.password, this.standerd, this.sid);
            int result=s1.Update(this.name, this.email, this.password, this.standerd, this.sid);
            out.print("<h1>"+result+"</h1>");
            if(result==1)
            {
                res.sendRedirect(req.getContextPath()+"/profile_update.jsp");
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    
    }
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException , ServletException
    {
        this.name=req.getParameter("name");
        this.email=req.getParameter("email");
        this.password=req.getParameter("password");
        this.standerd=req.getParameter("standerd");
        
        Random rand=new Random();
        int max=500;
        int min=1;
        this.sid=rand.nextInt(max - min + 1) + min;
        try {
        StudnetDatabase s=new StudnetDatabase();
        StudnetDatabase s1=new StudnetDatabase(this.name, this.email, this.password, this.standerd, this.sid);
        s1.setArrayListinfo(s1);
        int result=s1.SignUp(this.name, this.email, this.password, this.standerd, this.sid);
        out=res.getWriter();
        out.print("<h1>"+result+"</h1>");
            if(result==1)
            {
                ArrayList<StudnetDatabase> AL=s1.getArrayListinfo();
                res.sendRedirect(req.getContextPath()+"/index.html");
                for (StudnetDatabase e : AL) {
                    //VESUALIZATION
                    out.print("<h3>SID: "+e.getStanderd()+" Student Name: "+e.getName()+"</h3>");
                }
            }
            else
            {
                out.print("<h1>Look like person already Exists</h1>");
            }
        } catch (Exception e) {
            System.out.println("Student Servlet"+e);
        }
       
    }
}
