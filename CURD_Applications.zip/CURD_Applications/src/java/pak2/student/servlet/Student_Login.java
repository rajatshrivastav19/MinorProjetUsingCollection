package pak2.student.servlet;
import pak1.student.database.StudnetDatabase;

import java.util.*;
import java.io.*;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/student_Login")
public class Student_Login extends HttpServlet {

    String email,password;
    boolean result=false;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  
    {
        try {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            this.email=request.getParameter("email");
            this.password=request.getParameter("password");
            StudnetDatabase s1=new StudnetDatabase();
            this.result=s1.LoginPage(this.email,this.password);
            out.print("<h1>"+result+"</h1>");
            if(result)
            {
                 request.setAttribute("email", this.email);
                 RequestDispatcher rd = request.getRequestDispatcher("profile.jsp"); 
                 rd.forward(request, response); 
                 
                 //response.sendRedirect(request.getContextPath()+"/profile.jsp");
            }else{
                response.sendRedirect(request.getContextPath()+"/index.html");
            }
        } catch (SQLException ex) {
            System.out.println("pak2.student.servlet.Student_Login.doGet()"+ex);
        }
       
       
      
   
    }
 }
