
package pak1.student.database;

import java.sql.*;

public class GetDatabase {
    
    private String name, email, standerd,password;
    private int sid;
    Connection conn;
    boolean result;
    public GetDatabase()
    {
        try 
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
	    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","tiger");
            result=conn.getAutoCommit();
            System.out.println("try connection"+result);
        }catch (Exception e) 
        {
            System.out.println("try connection"+result);
            System.out.println("catch connection"+e);
        }
    }
    
    //GetStudentInfo
    public void GetStudentInfo(String email) throws SQLException
    {
            Statement stmt1=conn.createStatement();
            boolean result=false;
            String sql="SELECT * FROM student_registration";
            ResultSet rs=stmt1.executeQuery(sql);
            while(rs.next())
            {
                if(email.equals(rs.getString("EMAIL")))
                {
                    this.email=rs.getString("EMAIL");
                    this.name=rs.getString("NAME");
                    this.sid=Integer.parseInt(rs.getString("SID"));
                    this.standerd=rs.getString("CLASS");
                    this.password=rs.getString("PASSWORD");
                }
            }
    }
    //getter methods
    
    public String getName()
    {
        return this.name;
    }
    public String getEmail()
    {
        return this.email;
    }
    public String getStanderd()
    {
        return this.standerd;
    }
    public int getSid()
    {
        return this.sid;
    }
    public String getPassword()
    {
        return this.password;
    }
}
