package pak1.student.database;
import java.util.*;
import java.sql.*;
public class StudnetDatabase 
{
    Connection con;
    Connection conn;
    int statement;
    boolean result;
    private static ArrayList<StudnetDatabase> SS=new ArrayList();
    private String name,email,password,standerd;
    private int sid;
    
    public StudnetDatabase()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
	    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","tiger");
            result=conn.getAutoCommit();
            System.out.println("try connection"+result);
        } catch (Exception e) {
            System.out.println("try connection"+result);
            System.out.println("catch connection"+e);
        }
    }
    
    public StudnetDatabase(String name, String email, String password, String standerd, int sid)
    {
        this.email=email;
        this.name=name;
        this.password=password;
        this.standerd=standerd;
        this.sid=sid;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
	    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","tiger");
            result=con.getAutoCommit();
            System.out.println("try connection"+result);
        } catch (Exception e) {
            System.out.println("catch connection"+result);
            System.out.println("catch connection"+e);
        }
    }
    public int  SignUp(String name, String email, String password, String standerd, int sid) throws SQLException
    {

       try {
            Statement stmt=con.createStatement();
            String sql="INSERT INTO STUDENT_REGISTRATION VALUES ("+this.standerd+", '"+this.sid+"', '"+this.name+"', '"+this.email+"', '"+this.password+"')";
            statement=stmt.executeUpdate(sql);
            System.out.println("StudnetDatabase"+statement);
            if(statement==1)
                return statement; 
        } catch (Exception e) {
            System.out.println("StudentDatabase"+e);
        }   
        return statement;
    }
    
    public int  Update(String name, String email, String password, String standerd, int sid) throws SQLException
    {

       try {
            Statement stmt=con.createStatement();
            //String sql="INSERT INTO STUDENT_REGISTRATION VALUES ("+this.standerd+", '"+this.sid+"', '"+this.name+"', '"+this.email+"', '"+this.password+"')";
            String sql = "update STUDENT_REGISTRATION set NAME='"+this.name+"', CLASS="+this.standerd+",PASSWORD='"+this.password+"' where email='"+this.email+"'";
            statement=stmt.executeUpdate(sql);
            System.out.println("StudnetDatabase"+statement);
            if(statement==1)
                return statement; 
        } catch (Exception e) {
            System.out.println("StudentDatabase"+e);
        }   
        return statement;
    }

    public ArrayList<StudnetDatabase> getArrayListinfo() {
        return this.SS;
    }

    public void setArrayListinfo(StudnetDatabase s1) {
        SS.add(s1);
    }
    
    public int getSid(){
	return sid;
    }

    public String getName() {
	return this.name;
    }

    public String getRollno() {
	return this.email;
    }

    public String getPassword() {
	return this.password;
    }
    
    public String getStanderd(){
        return this.standerd;
    }

    public boolean LoginPage(String email, String password) throws SQLException {
            Statement stmt1=conn.createStatement();
            boolean result=false;
            String sql="SELECT * FROM student_registration";
            ResultSet rs=stmt1.executeQuery(sql);
            while(rs.next()){
                if(email.equals(rs.getString("EMAIL")) && password.equals(rs.getString("PASSWORD"))){
                    return true;
                }
            }
            return  result;
    }
}
